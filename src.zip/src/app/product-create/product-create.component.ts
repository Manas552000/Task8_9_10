import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-product-create',
  templateUrl: './product-create.component.html',
  styleUrls: ['./product-create.component.css']
})
export class ProductCreateComponent implements OnInit {

  //constructor() { }
  productForm:FormGroup;
  constructor(private http:HttpClient) { 
    this.productForm=new FormGroup({
      'name':new FormControl('',[Validators.required,Validators.minLength(5)]),
      'email':new FormControl('',[Validators.required,Validators.email]),
      'state':new FormControl(''),
      'country': new FormControl('')
    })
  }

  ngOnInit(): void {
  }
  postData(){
 
    if(this.productForm.valid){
      //console.log(this.productForm.value);
      this.http.post("https://6273665e6b04786a09057334.mockapi.io/products",this.productForm.value).subscribe((data)=>{
        alert("Data Saved");
      });
    }
    else{
      alert("Not valid");
    }
    
    
   
  }

}

 // ngOnInit(): void {
  //}


