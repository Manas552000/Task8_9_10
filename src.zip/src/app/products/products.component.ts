import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

 // constructor() { }
 userList:any;
  constructor(private http:HttpClient) { 
    
      this.http.get("https://6273665e6b04786a09057334.mockapi.io/products").subscribe((data)=>{
      //console.log(data);
      this.userList=data;
      });
  }

  ngOnInit(): void {
  }

}
