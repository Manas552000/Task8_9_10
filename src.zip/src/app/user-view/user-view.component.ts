import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-view',
  templateUrl: './user-view.component.html',
  styleUrls: ['./user-view.component.css']
})
export class UserViewComponent implements OnInit {
  currentUserId=1;
  userData:any;
  constructor(private activatedRoute:ActivatedRoute,private http:HttpClient) { 
    this.currentUserId=this.activatedRoute.snapshot.params['id']
    this.http.get(`https://6273665e6b04786a09057334.mockapi.io/students/${this.currentUserId}`).subscribe((data)=>{
      this.userData=data;
    })
  }

  ngOnInit(): void {
  }

}
